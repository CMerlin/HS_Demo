#ifndef _VIDEO_EQ_H_
#define _VIDEO_EQ_H_

void nvp6124_set_equalizer(void);

#endif

