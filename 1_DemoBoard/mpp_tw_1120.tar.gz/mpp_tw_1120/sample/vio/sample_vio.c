/******************************************************************************
  A simple program of Hisilicon HI3521A video input and output implementation.
  Copyright (C), 2014-2015, Hisilicon Tech. Co., Ltd.
 ******************************************************************************
    Modification:  2015-1 Created
******************************************************************************/

#ifdef __cplusplus
#if __cplusplus
extern "C"{
#endif
#endif /* End of #ifdef __cplusplus */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ioctl.h>

#include "sample_comm.h"

#define HDMI_SUPPORT

#if 1
int demoFunc();
#define VI_MAX_CH 33 /*3531A中VI的最大通道数*/
#define VO_AMX_LAYER_CH 64 /*3531A中,VO的每个视频层支持的最大通道数*/
#endif


/******************************************************************************
* function : show usage
******************************************************************************/
void SAMPLE_VIO_Usage(char *sPrgNm)
{
    printf("Usage : %s + <index> (eg: %s 0)\n", sPrgNm,sPrgNm);
    printf("index:\n");
	printf("\t0:  VI 8Mux 1080P input, HD0(VGA+BT1120),HD1(HDMI)/SD VO \n");	
	printf("\t1:  VI 1Mux 1080p input, HD ZoomIn\n");	
	printf("\tq:  quit\n");

    return;
}

/******************************************************************************
* function : to process abnormal case                                         
******************************************************************************/
void SAMPLE_VIO_HandleSig(HI_S32 signo)
{
    if (SIGINT == signo || SIGTSTP == signo)
    {
        SAMPLE_COMM_SYS_Exit();
        printf("\033[0;31mprogram termination abnormally!\033[0;39m\n");
    }
    exit(-1);
}

#if 1
/**************************************************************************************
* Description:禁止掉指定的VI设备
* Input:-1-所有的VI通道 0>=指定的通道号
**************************************************************************************/
int disVICHNum(VI_CHN chNum){
	HI_S32 s32Ret = 0, count = 0, ch = 0, num = 0;

	printf("[%s]:chNum=%d line:%d\n", __func__, chNum, __LINE__);
	/*禁止掉某通道*/
	if((-1) != chNum){
		s32Ret = HI_MPI_VI_DisableChn(chNum);
		if (HI_SUCCESS != s32Ret){
			SAMPLE_PRT("[%s]:failed with %#x\n", __func__, s32Ret);
			return HI_FAILURE;
		}
		return 0;
	}
	/*禁止掉所有的通道*/
	for(ch = 0; ch < VI_MAX_CH; ch++){
		num += 4; /*0 4 8 12 16 20 24 28 输出的是1080P的视频*/
		s32Ret = HI_MPI_VI_DisableChn(num);
		if (HI_SUCCESS != s32Ret){
			SAMPLE_PRT("[%s]:failed with %#x\n", __func__, s32Ret);
			return HI_FAILURE;
		}
	}
	return 0;
}

/****************************************************************************************
* Description:保留某个VI通道有输入
* Input:需要保留的通道
* Return:0-成功 0<-失败
***************************************************************************************/
int onlyVICHNum(VI_CHN chNum){
	HI_S32 s32Ret = 0,  ch = 0;
	
	printf("[%s]:chNum=%d line:%d\n", __func__, chNum, __LINE__);
	for(ch = 0; ch < VI_MAX_CH; ch++){
		if(ch == chNum){continue;} /*0 4 8 12 16 20 24 28 输出的是1080P的视频*/
		s32Ret = HI_MPI_VI_DisableChn(ch);
		if (HI_SUCCESS != s32Ret){
			SAMPLE_PRT("[%s]:failed with %#x\n", __func__, s32Ret);
			return HI_FAILURE;
		}
	}
	return 0;
}

/****************************************************************************************
* Description:禁掉某个视频层上的某个通道
* Input:layer-层号
* Input chNum:0>=禁止掉对应的通道号 -1-禁止掉所有的通道号
* Return:0-成功 0<-失败
***************************************************************************************/
int disVOCHNum(VO_LAYER layer, VO_CHN chNum){
	HI_S32 s32Ret = 0, ch = 0;

	printf("[%s]:layer=%d chNUm=%d line:%d\n", __func__, layer, chNum, __LINE__);
	s32Ret= HI_MPI_VO_SetAttrBegin(layer); /*设置视频层上的通道的设置属性开始*/
	/*禁掉某通道*/
	if((-1) != chNum){
		s32Ret = HI_MPI_VO_DisableChn(layer, chNum); /*禁用指定的视频输出通道*/
		if (s32Ret != HI_SUCCESS){
			SAMPLE_PRT("[%s]:failed with %#x!\n", __func__, s32Ret);
			return HI_FAILURE;
		}
		return 0;
	}
	else{
		/*禁掉所有通道*/
		for(ch = 0; ch < VO_AMX_LAYER_CH; ch++){
			s32Ret = HI_MPI_VO_DisableChn(layer, ch); /*禁用指定的视频输出通道*/
			if (s32Ret != HI_SUCCESS){
				SAMPLE_PRT("[%s]:failed with %#x!\n", __func__, s32Ret);
				return HI_FAILURE;
			}
		}
	}
	s32Ret= HI_MPI_VO_SetAttrEnd(layer); /*设置视频层上的通道的设置属性结束*/
	if (HI_SUCCESS != s32Ret){
		SAMPLE_PRT("[%s]:failed with %#x!\n", __func__, s32Ret);
		return 0;
	}	
	return 0;
}

/****************************************************************************************
* Description:保留某个VO通道有输入
* Input:需要保留的通道
* Return:0-成功 0<-失败
***************************************************************************************/
int onlyVOCHNum(VO_LAYER layer, VO_CHN chNum){
	HI_S32 s32Ret = 0,  ch = 0, num = 0;
	
	printf("[%s]:layer=%d chNUm=%d line:%d\n", __func__, layer, chNum, __LINE__);
	for(ch = 0; ch < VO_AMX_LAYER_CH; ch++){
		if(chNum == ch){continue;}
		s32Ret = HI_MPI_VO_DisableChn(layer, ch); /*禁用指定的视频输出通道*/
		if (HI_SUCCESS != s32Ret){
			SAMPLE_PRT("[%s]:failed with %#x\n", __func__, s32Ret);
			return HI_FAILURE;
		}
	}
	return 0;
}
#endif

/*********************************************************************
 * Description:开启VGA设备X视频层上X通道
 **********************************************************************/
int openVOLayerCH(VO_LAYER VoLayer, HI_S32 VOChNum){
	VO_DEV VoDev;
	VO_PUB_ATTR_S stVoPubAttr_hd0;
	VO_VIDEO_LAYER_ATTR_S stLayerAttr;
	VO_CHN_ATTR_S stChnAttr;
	HI_S32 s32Ret = HI_SUCCESS;
	SAMPLE_VO_MODE_E enVoMode;
	//VO_LAYER VoLayer;

	/*开启VGA设备*/
	//printf("[%s]:open VGA device line:%d\n", __func__, __LINE__);
	VoDev = SAMPLE_VO_DEV_DHD0;
	stVoPubAttr_hd0.enIntfSync = VO_OUTPUT_1080P60; /*Vo接口时序类型*/
	//stVoPubAttr_hd0.enIntfType = VO_INTF_BT1120|VO_INTF_VGA; /*Vo 接口类型*/
	stVoPubAttr_hd0.enIntfType = VO_INTF_BT1120|VO_INTF_VGA | VO_INTF_HDMI; /*Vo 接口类型*/
	stVoPubAttr_hd0.u32BgColor = 0x000000ff; /*0x00ff60 设备背景色 RGB表示*/
	s32Ret = SAMPLE_COMM_VO_StartDev(VoDev, &stVoPubAttr_hd0); /*设置并使能VO设备*/
	if (HI_SUCCESS != s32Ret){
		SAMPLE_PRT("Start SAMPLE_COMM_VO_StartDev failed!\n");
		return HI_FAILURE;
	}
	/*设置并使能视频层属性*/
	memset(&(stLayerAttr), 0 , sizeof(VO_VIDEO_LAYER_ATTR_S));
	s32Ret = SAMPLE_COMM_VO_GetWH(stVoPubAttr_hd0.enIntfSync, \
			&stLayerAttr.stImageSize.u32Width, \
			&stLayerAttr.stImageSize.u32Height, \
			&stLayerAttr.u32DispFrmRt);
	if (HI_SUCCESS != s32Ret)
	{
		SAMPLE_PRT("[%s]:Start SAMPLE_COMM_VO_GetWH failed!\n", __func__);
		return HI_FAILURE;
	}
	/*视频显示的坐标还有大小*/
	stLayerAttr.enPixFormat = SAMPLE_PIXEL_FORMAT; /*视频层使用的像素格式*/
	stLayerAttr.stDispRect.s32X       = 0;
	stLayerAttr.stDispRect.s32Y       = 0;
	stLayerAttr.stDispRect.u32Width   = stLayerAttr.stImageSize.u32Width;
	stLayerAttr.stDispRect.u32Height  = stLayerAttr.stImageSize.u32Height;
	//VoLayer = SAMPLE_VO_LAYER_VHD0; /*视频层*/
	s32Ret = SAMPLE_COMM_VO_StartLayer(VoLayer, &stLayerAttr); /*设置并使能视频层属性*/
	if (HI_SUCCESS != s32Ret){
		SAMPLE_PRT("Start SAMPLE_COMM_VO_StartLayer failed!\n");
		//goto END_8_1080P_4;
		return HI_FAILURE;
	}
	/*设置并使能视频通道*/
	memset(&stLayerAttr, 0, sizeof(stLayerAttr));
	s32Ret = HI_MPI_VO_GetVideoLayerAttr(VoLayer, &stLayerAttr); /*获取视频层属性*/
	if (s32Ret != HI_SUCCESS){
		SAMPLE_PRT("failed with %#x!\n", s32Ret);
		return HI_FAILURE;
	}
	stChnAttr.stRect.s32X       = 0; //ALIGN_BACK((u32Width/u32Square) * (i%u32Square), 2);
	stChnAttr.stRect.s32Y       = 0; //ALIGN_BACK((u32Height/u32Square) * (i/u32Square), 2);
	stChnAttr.stRect.u32Width   = stLayerAttr.stDispRect.u32Width; //ALIGN_BACK(u32Width/u32Square, 2);
	stChnAttr.stRect.u32Height  = stLayerAttr.stDispRect.u32Height; //ALIGN_BACK(u32Height/u32Square, 2);
	stChnAttr.u32Priority       = 0; /*视频层优先级*/
	stChnAttr.bDeflicker        = HI_FALSE; /*是否开启抗闪烁*/
	printf("[%s]:enable VO=%d-%d  line:%d\n", __func__, VoLayer , VOChNum,  __LINE__);
	s32Ret = HI_MPI_VO_SetChnAttr(VoLayer, VOChNum, &stChnAttr); /*配置指定视频输出通道的属性*/
	if (s32Ret != HI_SUCCESS){
		printf("%s(%d):failed with %#x!\n",__FUNCTION__,__LINE__,  s32Ret);
		return HI_FAILURE;
	}
	 /*启用指定的视频输出通道*/
	s32Ret = HI_MPI_VO_EnableChn(VoLayer, VOChNum);
	if (s32Ret != HI_SUCCESS){
		SAMPLE_PRT("failed with %#x!\n", s32Ret);
		return HI_FAILURE;
	}

#ifdef HDMI_SUPPORT
		/* 如果支持HDMI接口，初始化HDMI数据 */
		if (stVoPubAttr_hd0.enIntfType & VO_INTF_HDMI)
		{
			if (HI_SUCCESS != SAMPLE_COMM_VO_HdmiStart(stVoPubAttr_hd0.enIntfSync))
			{
				SAMPLE_PRT("[%s]:Start SAMPLE_COMM_VO_HdmiStart failed!\n", __func__);
				//goto END_8_1080P_7;
				return -1;
			}
		}
#endif

	//SAMPLE_COMM_VO_StartChn();
	return 0;
}

/*******************************************************************************
* Description:开启某个VO通道
*******************************************************************************/
int startVOCHx(VO_LAYER VoLayer, HI_S32 VOChNum){
	HI_S32 s32Ret = HI_SUCCESS;
	VO_VIDEO_LAYER_ATTR_S stLayerAttr;
	VO_CHN_ATTR_S stChnAttr;

	s32Ret= HI_MPI_VO_SetAttrBegin(VoLayer); /*设置视频层上的通道的设置属性开始*/
	if (HI_SUCCESS != s32Ret){
		SAMPLE_PRT("[%s]:failed with %#x!\n", __func__, s32Ret);
		return 0;
	}
	/*设置并使能视频通道*/
	memset(&stLayerAttr, 0, sizeof(stLayerAttr));
	s32Ret = HI_MPI_VO_GetVideoLayerAttr(VoLayer, &stLayerAttr); /*获取视频层属性*/
	if (s32Ret != HI_SUCCESS){
		SAMPLE_PRT("failed with %#x!\n", s32Ret);
		return HI_FAILURE;
	}
	/*下面的这些值决定，此通到的显示位置和图像的大小*/
	stChnAttr.stRect.s32X       = 0; //ALIGN_BACK((u32Width/u32Square) * (i%u32Square), 2);
	stChnAttr.stRect.s32Y       = 0; //ALIGN_BACK((u32Height/u32Square) * (i/u32Square), 2);
	stChnAttr.stRect.u32Width   = 720;//stLayerAttr.stDispRect.u32Width; //ALIGN_BACK(u32Width/u32Square, 2);
	stChnAttr.stRect.u32Height  = 480;//stLayerAttr.stDispRect.u32Height; //ALIGN_BACK(u32Height/u32Square, 2);
	stChnAttr.u32Priority       = 0; /*视频层优先级*/
	stChnAttr.bDeflicker        = HI_TRUE; /*是否开启抗闪烁*/
	printf("[%s]:enable VO=%d-%d  line:%d\n", __func__, VoLayer , VOChNum,  __LINE__);
	s32Ret = HI_MPI_VO_SetChnAttr(VoLayer, VOChNum, &stChnAttr); /*配置指定视频输出通道的属性*/
	if (s32Ret != HI_SUCCESS){
		SAMPLE_PRT("[%s]:Start HI_MPI_VO_SetChnAttr failed!\n", __func__);
		return HI_FAILURE;
	}
	 /*启用指定的视频输出通道*/
	s32Ret = HI_MPI_VO_EnableChn(VoLayer, VOChNum);
	if (s32Ret != HI_SUCCESS){
		SAMPLE_PRT("failed with %#x!\n", s32Ret);
		return HI_FAILURE;
	}
	s32Ret= HI_MPI_VO_SetAttrEnd(VoLayer); /*设置视频层上的通道的设置属性结束*/
	if (HI_SUCCESS != s32Ret){
		SAMPLE_PRT("[%s]:failed with %#x!\n", __func__, s32Ret);
		return 0;
	}
	return 0;
}


/***************************************************************************************
* Description:设置 VO中 VGA
*****************************************************************************************/
int setVOAttrVGA(){
	VPSS_CHN VpssChn_VoHD0 = VPSS_CHN1;
	VPSS_GRP VpssGrp;
	HI_S32 s32Ret = HI_SUCCESS, i = 0;
	VO_DEV VoDev;
	VO_LAYER VoLayer;
	VO_CHN VoChn;
	HI_U32 u32WndNum;
	SAMPLE_VO_MODE_E enVoMode;
	VO_PUB_ATTR_S stVoPubAttr_hd0;
	VO_VIDEO_LAYER_ATTR_S stLayerAttr;
	#if 1 /*输出设备：J10 VGA输出*/	
	/******************************************
	 step 5: start vo HD0 (bt1120+VGA), multi-screen, you can switch mode
	******************************************/
	printf("\n[%s]:****** start step 5: start vo HD0 (bt1120+VGA). ****** line:%d\n", __func__, __LINE__);
	VoDev = SAMPLE_VO_DEV_DHD0;
	stVoPubAttr_hd0.enIntfSync = VO_OUTPUT_1080P60; /*Vo接口时序类型*/
	stVoPubAttr_hd0.enIntfType = VO_INTF_BT1120|VO_INTF_VGA; /*Vo 接口类型*/
	stVoPubAttr_hd0.u32BgColor = 0x000000ff; /*0x00ff60 设备背景色 RGB表示*/
	s32Ret = SAMPLE_COMM_VO_StartDev(VoDev, &stVoPubAttr_hd0); /*设置并使能VO设备*/
	if (HI_SUCCESS != s32Ret)
	{
		SAMPLE_PRT("Start SAMPLE_COMM_VO_StartDev failed!\n");
		//goto END_8_1080P_3;
		return HI_FAILURE;
	}
	/*视频层相关属性*/
	memset(&(stLayerAttr), 0 , sizeof(VO_VIDEO_LAYER_ATTR_S));
	s32Ret = SAMPLE_COMM_VO_GetWH(stVoPubAttr_hd0.enIntfSync, \
		&stLayerAttr.stImageSize.u32Width, \
		&stLayerAttr.stImageSize.u32Height, \
		&stLayerAttr.u32DispFrmRt);
	if (HI_SUCCESS != s32Ret)
	{
		SAMPLE_PRT("Start SAMPLE_COMM_VO_GetWH failed!\n");
		//goto END_8_1080P_4;
		return HI_FAILURE;
	}
	/*视频显示的坐标还有大小*/
	stLayerAttr.enPixFormat = SAMPLE_PIXEL_FORMAT; /*视频层使用的像素格式*/
    stLayerAttr.stDispRect.s32X       = 0;
    stLayerAttr.stDispRect.s32Y       = 0;
    stLayerAttr.stDispRect.u32Width   = stLayerAttr.stImageSize.u32Width;
    stLayerAttr.stDispRect.u32Height  = stLayerAttr.stImageSize.u32Height;
	VoLayer = SAMPLE_VO_LAYER_VHD0;
	s32Ret = SAMPLE_COMM_VO_StartLayer(VoLayer, &stLayerAttr); /*设置并使能视频层属性*/
	if (HI_SUCCESS != s32Ret)
	{
		SAMPLE_PRT("Start SAMPLE_COMM_VO_StartLayer failed!\n");
		//goto END_8_1080P_4;
		return HI_FAILURE;
	}
	 /*设置并使能视频通道*/
	enVoMode = VO_MODE_9MUX;
	s32Ret = SAMPLE_COMM_VO_StartChn(VoLayer, enVoMode);
	if (HI_SUCCESS != s32Ret)
	{
		SAMPLE_PRT("Start SAMPLE_COMM_VO_StartChn failed!\n");
		//goto END_8_1080P_5;
		return HI_FAILURE;
	}
	/*vpass 和 VO设备之间建立bind关系*/
	u32WndNum = 8;
	printf("\n[%s]:bind vpass and VO:", __func__);
	for(i=0;i<u32WndNum;i++)
	{
		VoChn = i;
		VpssGrp = i;
		printf("vpas=%d-%d VO=%d-%d  ", VpssGrp, VpssChn_VoHD0, VoDev, VoChn);
		s32Ret = SAMPLE_COMM_VO_BindVpss(VoDev,VoChn,VpssGrp,VpssChn_VoHD0);
		if (HI_SUCCESS != s32Ret)
		{
			SAMPLE_PRT("Start VO failed!\n");
			//goto END_8_1080P_5;
			return HI_FAILURE;
		}
	}
#endif
	return 0;
}

/*****************************************************************************
* Description:mpp的初始化
*****************************************************************************/
int initMpp(){
	
	HI_S32 s32Ret = HI_SUCCESS;
	HI_U32 u32BlkSize = 0;
	HI_U32 u32ViChnCnt = 8;
	VB_CONF_S stVbConf; /*定义视频缓存池属性结构体*/
	//SAMPLE_VI_MODE_E enViMode = SAMPLE_VI_MODE_8_1080P; //SAMPLE_VI_MODE_8_720P; //SAMPLE_VI_MODE_8_1080P;
	VIDEO_NORM_E enNorm = VIDEO_ENCODING_MODE_AUTO; /*视频输入制式类型*/
	
	printf("[%s]:Begin line:%d\n", __func__, __LINE__);
	/******************************************
	 step  1: init variable 
	******************************************/	
	printf("[%s]:****** step  1: init variable ****** line:%d\n", __func__, __LINE__);
	memset(&stVbConf,0,sizeof(VB_CONF_S));
	u32BlkSize = SAMPLE_COMM_SYS_CalcPicVbBlkSize(enNorm,\
				PIC_HD1080, SAMPLE_PIXEL_FORMAT, SAMPLE_SYS_ALIGN_WIDTH,COMPRESS_MODE_SEG);
	stVbConf.u32MaxPoolCnt = 128; /*系统所能容纳的缓存池的个数*/

	/* video buffer*/
	//todo: vb=15
	stVbConf.astCommPool[0].u32BlkSize = u32BlkSize; /*公共缓存快的0的大小*/
	stVbConf.astCommPool[0].u32BlkCnt = u32ViChnCnt * 8; /*缓存块的个数*/

	/******************************************
	 step 2: mpp system init. 
	******************************************/
	printf("[%s]:******  step 2: mpp system init.  ****** line:%d\n", __func__, __LINE__);
	s32Ret = SAMPLE_COMM_SYS_Init(&stVbConf); /*mpp的初始化设置*/
	if (HI_SUCCESS != s32Ret)
	{
		SAMPLE_PRT("system init failed with %d!\n", s32Ret);
		//goto END_8_1080P_0;
		return -1;
	}
	return 0;
}

/******************************************************************************
* Description：解bind某路AI和AO0的bind关系
* Input:type-操作类型bind或是unbind 
* Input:pstSrcChn-源通道道路 pstDestChn-目标通道
******************************************************************************/
HI_S32 bindORunBindAIAO(HI_S32 type, MPP_CHN_S *pstSrcChn, MPP_CHN_S *pstDestChn){
	HI_S32 s32Ret = 0; 

	printf("[%s]:type=%d VI=%d-%d VO-%d-%d line:%d\n", __func__, type, (pstSrcChn->s32DevId), \
		(pstSrcChn->s32ChnId), (pstDestChn->s32DevId), (pstDestChn->s32ChnId), __LINE__);
	if(1 == type){	
		s32Ret = HI_MPI_SYS_Bind(pstSrcChn, pstDestChn); /*bind操作*/
		if (s32Ret != HI_SUCCESS){
			SAMPLE_PRT("[%s]:failed with bind %#x!\n", __func__, s32Ret);
			return HI_FAILURE;
		}
		return 0;
	}
	s32Ret = HI_MPI_SYS_UnBind(pstSrcChn, pstDestChn); /*解bind操作*/
	if (s32Ret != HI_SUCCESS){
		SAMPLE_PRT("[%s]:failed with Unbind %#x!\n", __func__, s32Ret);
		return HI_FAILURE;
	}
	return 0;
}

/*********************************************************************************************************
* func:获取某路VI输入，直接通过VGA输出
*********************************************************************************************************/
int funcVOFromVI(){
	HI_S32 s32VpssGrpCnt = 8;
	SIZE_S stSize;
	HI_S32 s32Ret = HI_FAILURE;
	VO_VIDEO_LAYER_ATTR_S stLayerAttr;
	VPSS_GRP_ATTR_S stGrpAttr; /*vpass 静态属性信息*/
	SAMPLE_VI_MODE_E enViMode = SAMPLE_VI_MODE_8_1080P; //SAMPLE_VI_MODE_8_720P; //SAMPLE_VI_MODE_8_1080P;
	VIDEO_NORM_E enNorm = VIDEO_ENCODING_MODE_AUTO; /*视频输入制式类型*/
	VO_LAYER VoLayer = SAMPLE_VO_LAYER_VHD0; /*视频层*/
	HI_S32 VOCHNum = 0; /*VO通道号*/
	MPP_CHN_S stSrcChn;
	MPP_CHN_S stDestChn;
	HI_S32 VIChNum = 0; /*VI通道号*/
	HI_S32 VIDevNum = 0; /*VI设备号*/

	initMpp();
	printf("[%s]:****** step 3: start vi dev & chn ****** line:%d\n", __func__, __LINE__);
	s32Ret = SAMPLE_COMM_VI_Start(enViMode, enNorm); /*开启VI设备*/
	if (HI_SUCCESS != s32Ret){
		SAMPLE_PRT("[%s]:start vi failed!\n", __func__);
		return -1;
	}
	/*设置VGA的属性*/
	VOCHNum = 0;
	openVOLayerCH(VoLayer, VOCHNum); /*打开VO设备X视频层的X通道*/
	/* VI和VO进行通道bind     , 源通道指针*/
	VIDevNum = 0;
	VIChNum = 12;
	stSrcChn.enModId = HI_ID_VIU; /*模块号*/
	stSrcChn.s32DevId = VIDevNum; /*设备号*/
	stSrcChn.s32ChnId = VIChNum; /*通道号*/
	/*目的通道指针*/
	stDestChn.enModId = HI_ID_VOU;
	stDestChn.s32DevId = VoLayer;
	stDestChn.s32ChnId = VOCHNum;
	/*数据源到数据接收者绑定*/
	printf("[%s]:VI=%d-%d VO=%d-%d line:%d\n", __func__, VIDevNum, VIChNum, VoLayer, VOCHNum, __LINE__);
	s32Ret = HI_MPI_SYS_Bind(&stSrcChn, &stDestChn);
	if (s32Ret != HI_SUCCESS){
		SAMPLE_PRT("[%s]:failed with %#x!\n", __func__, s32Ret);
		return HI_FAILURE;
	}
	
	return 0;
}


/****************************************************************************************
* Description:将不同的VI通过VGA的视频层0通道0输出
****************************************************************************************/
int showVINum(HI_S32 chNum){
	MPP_CHN_S sSrcChn, sDestChn;

	disVOCHNum(0, 0); /*将VO的0层的0通道禁掉*/
	memset(&sSrcChn, 0, sizeof(sSrcChn));
	memset(&sDestChn, 0, sizeof(sDestChn));
	sSrcChn.enModId = HI_ID_VIU; /*模块号*/
	sSrcChn.s32DevId = 0; /*设备号*/
	sSrcChn.s32ChnId = chNum; /*通道号*/
	/*目的通道指针*/
	sDestChn.enModId = HI_ID_VOU;
	sDestChn.s32DevId = SAMPLE_VO_LAYER_VHD0;
	sDestChn.s32ChnId = 0;
	printf("[%s]:show VI=%d-%d VO=%d-%d line:%d\n", __func__, (sSrcChn.s32DevId), (sSrcChn.s32ChnId), \
		(sDestChn.s32DevId), (sDestChn.s32ChnId),  __LINE__);
	/*数据源到数据接收者绑定*/
	//openVOLayerCH((sDestChn.s32DevId), (sDestChn.s32ChnId)); /*打开VO设备X视频层的X通道*/
	startVOCHx((sDestChn.s32DevId), (sDestChn.s32ChnId)); /*打开VO设备X视频层的X通道*/
	bindORunBindAIAO(0, &sSrcChn, &sDestChn); /*bind*/
	bindORunBindAIAO(1, &sSrcChn, &sDestChn); /*unbind*/

	return 0;
}

/****************************************************************************************
* Description:将VI 0-0通0-X通道输出
****************************************************************************************/
int showVONum(HI_S32 chNum){
	MPP_CHN_S sSrcChn, sDestChn;
	
	disVOCHNum(0, -1); /*将VO的0层的所有通道禁掉*/
	memset(&sSrcChn, 0, sizeof(sSrcChn));
	memset(&sDestChn, 0, sizeof(sDestChn));
	sSrcChn.enModId = HI_ID_VIU; /*模块号*/
	sSrcChn.s32DevId = 0; /*设备号*/
	sSrcChn.s32ChnId = 12; /*通道号*/
	/*目的通道指针*/
	sDestChn.enModId = HI_ID_VOU;
	sDestChn.s32DevId = SAMPLE_VO_LAYER_VHD0;
	sDestChn.s32ChnId = chNum;
	/*数据源到数据接收者绑定*/
	//openVOLayerCH((sDestChn.s32DevId), (sDestChn.s32ChnId)); /*打开VO设备X视频层的X通道*/
	startVOCHx((sDestChn.s32DevId), (sDestChn.s32ChnId)); /*打开VO设备X视频层的X通道*/
	bindORunBindAIAO(0, &sSrcChn, &sDestChn); /*bind*/
	bindORunBindAIAO(1, &sSrcChn, &sDestChn); /*unbind*/
	return 0;
}

/****************************************************************************************
* Description：在同一个设备上显示两个视频层
****************************************************************************************/
int layersDisplay(HI_S32 type){
	MPP_CHN_S sSrcChn, sDestChn;
	
	return 0;
}


/**************************************************************************************************
* Description:测试程序入口
****************************************************************************************************/
int demoFunc()
{
    HI_S32 s32Ret = HI_FAILURE;
	VO_DEV VoDev = SAMPLE_VO_DEV_DHD0;
	VO_LAYER VoLayer = SAMPLE_VO_LAYER_VHD0;
	char buffer[32] = {0};
	//SAMPLE_VO_MODE_E enVoMode, enPreVoMode;
	
	/*异常信号处理*/
    signal(SIGINT, SAMPLE_VIO_HandleSig);
    signal(SIGTERM, SAMPLE_VIO_HandleSig);
	funcVOFromVI();
	
	printf("\n[%s]:****** show VI=0-12 VO=0-0 ****** line:%d\n", __func__, __LINE__);
	while(1)
	{
		if(NULL == gets(buffer)){
			printf("[%s][Error]:wrong input data. line:%d\n", __func__, __LINE__);
			continue;
		}
		s32Ret = atoi(buffer);
		printf("[%s]:cmd=%d 100-quit VI=0 4...+4 VO=0 1....+1 line:%d\n", __func__, s32Ret, __LINE__);
		if(100 == s32Ret){
			break;
		}
		showVINum(s32Ret); /*将不同的VI输出到同一个VO通道上*/
		//showVONum(s32Ret); /*将同一个VI输出到不同的VO通道上*/
		//layersDisplay(s32Ret);
	}
	SAMPLE_COMM_SYS_Exit();
	return 0;
}

/******************************************************************************************************************
* End 
*******************************************************************************************************************/

/******************************************************************************
* function : VI(1080P: 8 windows) -> VPSS -> HD0(1080P,VGA,BT1120)
                                         -> HD1(1080P,HDMI)
                                         -> SD0(D1)
******************************************************************************/
HI_S32 SAMPLE_VIO_8_1080P(HI_VOID)
{
	SAMPLE_VI_MODE_E enViMode = SAMPLE_VI_MODE_8_1080P; //SAMPLE_VI_MODE_8_720P; //SAMPLE_VI_MODE_8_1080P;
	VIDEO_NORM_E enNorm = VIDEO_ENCODING_MODE_AUTO; /*视频输入制式类型*/

	HI_U32 u32ViChnCnt = 8;
	HI_S32 s32VpssGrpCnt = 8;
	
	VB_CONF_S stVbConf; /*定义视频缓存池属性结构体*/
	VPSS_GRP VpssGrp;
	VPSS_GRP_ATTR_S stGrpAttr; /*vpass 静态属性信息*/
    VPSS_CHN VpssChn_VoHD0 = VPSS_CHN1;	
	VPSS_CHN VpssChn_VoHD1 = VPSS_CHN2;
	VPSS_CHN VpssChn_VoSD0 = VPSS_CHN3;
	
	VO_DEV VoDev;
	VO_LAYER VoLayer;
	VO_CHN VoChn;
	VO_PUB_ATTR_S stVoPubAttr_hd0, stVoPubAttr_hd1, stVoPubAttr_sd;
	VO_VIDEO_LAYER_ATTR_S stLayerAttr;
	SAMPLE_VO_MODE_E enVoMode, enPreVoMode;
	
	HI_S32 i;
	HI_S32 s32Ret = HI_SUCCESS;
	HI_U32 u32BlkSize;
	HI_CHAR ch;
	SIZE_S stSize;
	HI_U32 u32WndNum;
	HI_U32 vichn;
	
	/******************************************
	 step  1: init variable 
	******************************************/	
	memset(&stVbConf,0,sizeof(VB_CONF_S));
	u32BlkSize = SAMPLE_COMM_SYS_CalcPicVbBlkSize(enNorm,\
				PIC_HD1080, SAMPLE_PIXEL_FORMAT, SAMPLE_SYS_ALIGN_WIDTH,COMPRESS_MODE_SEG);
	stVbConf.u32MaxPoolCnt = 128;

	/* video buffer*/
	//todo: vb=15
	stVbConf.astCommPool[0].u32BlkSize = u32BlkSize;
	stVbConf.astCommPool[0].u32BlkCnt = u32ViChnCnt * 8;

	/******************************************
	 step 2: mpp system init. 
	******************************************/
	s32Ret = SAMPLE_COMM_SYS_Init(&stVbConf);
	if (HI_SUCCESS != s32Ret)
	{
		SAMPLE_PRT("system init failed with %d!\n", s32Ret);
		goto END_8_1080P_0;
	}

	/******************************************
	 step 3: start vi dev & chn
	******************************************/
	s32Ret = SAMPLE_COMM_VI_Start(enViMode, enNorm);
	if (HI_SUCCESS != s32Ret)
	{
		SAMPLE_PRT("start vi failed!\n");
		goto END_8_1080P_0;
	}

	/******************************************
	 step 4: start vpss and vi bind vpss
	******************************************/
	s32Ret = SAMPLE_COMM_SYS_GetPicSize(enNorm, PIC_HD1080, &stSize);
	if (HI_SUCCESS != s32Ret)
	{
		SAMPLE_PRT("SAMPLE_COMM_SYS_GetPicSize failed!\n");
		goto END_8_1080P_1;
	}

	memset(&stGrpAttr,0,sizeof(VPSS_GRP_ATTR_S));
	stGrpAttr.u32MaxW = stSize.u32Width;
	stGrpAttr.u32MaxH = stSize.u32Height;
	stGrpAttr.bNrEn = HI_TRUE;
    stGrpAttr.enDieMode = VPSS_DIE_MODE_NODIE;
	stGrpAttr.enPixFmt = SAMPLE_PIXEL_FORMAT;
	s32Ret = SAMPLE_COMM_VPSS_Start(s32VpssGrpCnt, &stSize, VPSS_MAX_CHN_NUM, &stGrpAttr);
	if (HI_SUCCESS != s32Ret)
	{
		SAMPLE_PRT("Start Vpss failed!\n");
		goto END_8_1080P_1;
	}

	s32Ret = SAMPLE_COMM_VI_BindVpss(enViMode);
	if (HI_SUCCESS != s32Ret)
	{
		SAMPLE_PRT("Vi bind Vpss failed!\n");
		goto END_8_1080P_2;
	}

	/******************************************
	 step 5: start vo HD0 (bt1120+VGA), multi-screen, you can switch mode
	******************************************/
	printf("start vo HD0.\n");
	VoDev = SAMPLE_VO_DEV_DHD0;
	VoLayer = SAMPLE_VO_LAYER_VHD0;
	u32WndNum = 8;
	enVoMode = VO_MODE_9MUX;
	
	stVoPubAttr_hd0.enIntfSync = VO_OUTPUT_1080P60; /*Vo接口时序类型*/
	stVoPubAttr_hd0.enIntfType = VO_INTF_BT1120|VO_INTF_VGA; /*Vo 接口类型*/
	stVoPubAttr_hd0.u32BgColor = 0x000000ff; /*0x00ff60 设备背景色 RGB表示*/
	s32Ret = SAMPLE_COMM_VO_StartDev(VoDev, &stVoPubAttr_hd0); /*设置并使能VO设备*/
	if (HI_SUCCESS != s32Ret)
	{
		SAMPLE_PRT("Start SAMPLE_COMM_VO_StartDev failed!\n");
		goto END_8_1080P_3;
	}
	/*视频层相关属性*/
	memset(&(stLayerAttr), 0 , sizeof(VO_VIDEO_LAYER_ATTR_S));
	s32Ret = SAMPLE_COMM_VO_GetWH(stVoPubAttr_hd0.enIntfSync, \
		&stLayerAttr.stImageSize.u32Width, \
		&stLayerAttr.stImageSize.u32Height, \
		&stLayerAttr.u32DispFrmRt);
	if (HI_SUCCESS != s32Ret)
	{
		SAMPLE_PRT("Start SAMPLE_COMM_VO_GetWH failed!\n");
		goto END_8_1080P_4;
	}
	/*视频显示的坐标还有大小*/
	stLayerAttr.enPixFormat = SAMPLE_PIXEL_FORMAT; /*视频层使用的像素格式*/
    stLayerAttr.stDispRect.s32X       = 0;
    stLayerAttr.stDispRect.s32Y       = 0;
    stLayerAttr.stDispRect.u32Width   = stLayerAttr.stImageSize.u32Width;
    stLayerAttr.stDispRect.u32Height  = stLayerAttr.stImageSize.u32Height;
	s32Ret = SAMPLE_COMM_VO_StartLayer(VoLayer, &stLayerAttr);
	if (HI_SUCCESS != s32Ret)
	{
		SAMPLE_PRT("Start SAMPLE_COMM_VO_StartLayer failed!\n");
		goto END_8_1080P_4;
	}
	
	s32Ret = SAMPLE_COMM_VO_StartChn(VoLayer, enVoMode); /*设置并使能视频通道*/
	if (HI_SUCCESS != s32Ret)
	{
		SAMPLE_PRT("Start SAMPLE_COMM_VO_StartChn failed!\n");
		goto END_8_1080P_5;
	}
#ifdef HDMI_SUPPORT
	/* if it's displayed on HDMI, we should start HDMI */
	if (stVoPubAttr_hd0.enIntfType & VO_INTF_HDMI)
	{
		if (HI_SUCCESS != SAMPLE_COMM_VO_HdmiStart(stVoPubAttr_hd0.enIntfSync))
		{
			SAMPLE_PRT("Start SAMPLE_COMM_VO_HdmiStart failed!\n");
			goto END_8_1080P_5;
		}
	}
#endif
	for(i=0;i<u32WndNum;i++)
	{
		VoChn = i;
		VpssGrp = i;
		
		s32Ret = SAMPLE_COMM_VO_BindVpss(VoDev,VoChn,VpssGrp,VpssChn_VoHD0);
		if (HI_SUCCESS != s32Ret)
		{
			SAMPLE_PRT("Start VO failed!\n");
			goto END_8_1080P_5;
		}
	}


    /******************************************
	 step 5: start vo HD1 (HDMI), multi-screen, you can switch mode
	******************************************/
	printf("start vo HD1.\n");
	VoDev = SAMPLE_VO_DEV_DHD1;
	VoLayer = SAMPLE_VO_LAYER_VHD1;
	u32WndNum = 8;
	enVoMode = VO_MODE_9MUX;

	stVoPubAttr_hd1.enIntfSync = VO_OUTPUT_1080P60;
	stVoPubAttr_hd1.enIntfType = VO_INTF_HDMI;
	stVoPubAttr_hd1.u32BgColor = 0x000000ff;
	s32Ret = SAMPLE_COMM_VO_StartDev(VoDev, &stVoPubAttr_hd1);
	if (HI_SUCCESS != s32Ret)
	{
		SAMPLE_PRT("Start SAMPLE_COMM_VO_StartDev failed!\n");
		goto END_8_1080P_5;
	}

	memset(&(stLayerAttr), 0 , sizeof(VO_VIDEO_LAYER_ATTR_S));
	s32Ret = SAMPLE_COMM_VO_GetWH(stVoPubAttr_hd1.enIntfSync, \
		&stLayerAttr.stImageSize.u32Width, \
		&stLayerAttr.stImageSize.u32Height, \
		&stLayerAttr.u32DispFrmRt);
	if (HI_SUCCESS != s32Ret)
	{
		SAMPLE_PRT("Start SAMPLE_COMM_VO_GetWH failed!\n");
		goto END_8_1080P_6;
	}

	stLayerAttr.enPixFormat = SAMPLE_PIXEL_FORMAT;
    stLayerAttr.stDispRect.s32X       = 0;
    stLayerAttr.stDispRect.s32Y       = 0;
    stLayerAttr.stDispRect.u32Width   = stLayerAttr.stImageSize.u32Width;
    stLayerAttr.stDispRect.u32Height  = stLayerAttr.stImageSize.u32Height;
	s32Ret = SAMPLE_COMM_VO_StartLayer(VoLayer, &stLayerAttr);
	if (HI_SUCCESS != s32Ret)
	{
		SAMPLE_PRT("Start SAMPLE_COMM_VO_StartLayer failed!\n");
		goto END_8_1080P_6;
	}
	
	s32Ret = SAMPLE_COMM_VO_StartChn(VoLayer, enVoMode);
	if (HI_SUCCESS != s32Ret)
	{
		SAMPLE_PRT("Start SAMPLE_COMM_VO_StartChn failed!\n");
		goto END_8_1080P_7;
	}
#ifdef HDMI_SUPPORT
	/* if it's displayed on HDMI, we should start HDMI */
	if (stVoPubAttr_hd1.enIntfType & VO_INTF_HDMI)
	{
		if (HI_SUCCESS != SAMPLE_COMM_VO_HdmiStart(stVoPubAttr_hd1.enIntfSync))
		{
			SAMPLE_PRT("Start SAMPLE_COMM_VO_HdmiStart failed!\n");
			goto END_8_1080P_7;
		}
	}
#endif
	for(i=0;i<u32WndNum;i++)
	{
		VoChn = i;
		VpssGrp = i;
		
		s32Ret = SAMPLE_COMM_VO_BindVpss(VoDev,VoChn,VpssGrp,VpssChn_VoHD1);
		if (HI_SUCCESS != s32Ret)
		{
			SAMPLE_PRT("Start VO failed!\n");
			goto END_8_1080P_7;
		}
	}
	/******************************************
	step 6: start vo SD0 (CVBS)
	******************************************/
	printf("start vo SD0\n");
	VoDev = SAMPLE_VO_DEV_DSD0;
	VoLayer = SAMPLE_VO_LAYER_VSD0;
	u32WndNum = 8;
	enVoMode = VO_MODE_9MUX;
	
	stVoPubAttr_sd.enIntfSync = VO_OUTPUT_PAL;
	stVoPubAttr_sd.enIntfType = VO_INTF_CVBS;
	stVoPubAttr_sd.u32BgColor = 0x000000ff;
	s32Ret = SAMPLE_COMM_VO_StartDev(VoDev, &stVoPubAttr_sd);
	if (HI_SUCCESS != s32Ret)
	{
		SAMPLE_PRT("Start SAMPLE_COMM_VO_StartDev failed!\n");
		goto END_8_1080P_7;
	}
	
	memset(&(stLayerAttr), 0 , sizeof(VO_VIDEO_LAYER_ATTR_S));
	s32Ret = SAMPLE_COMM_VO_GetWH(stVoPubAttr_sd.enIntfSync, \
		&stLayerAttr.stImageSize.u32Width, \
		&stLayerAttr.stImageSize.u32Height, \
		&stLayerAttr.u32DispFrmRt);
	if (HI_SUCCESS != s32Ret)
	{
		SAMPLE_PRT("Start SAMPLE_COMM_VO_GetWH failed!\n");
		goto END_8_1080P_8;
	}
	
	stLayerAttr.enPixFormat = SAMPLE_PIXEL_FORMAT;
    stLayerAttr.stDispRect.s32X       = 0;
    stLayerAttr.stDispRect.s32Y       = 0;
    stLayerAttr.stDispRect.u32Width   = stLayerAttr.stImageSize.u32Width;
    stLayerAttr.stDispRect.u32Height  = stLayerAttr.stImageSize.u32Height;
	s32Ret = SAMPLE_COMM_VO_StartLayer(VoLayer, &stLayerAttr);
	if (HI_SUCCESS != s32Ret)
	{
		SAMPLE_PRT("Start SAMPLE_COMM_VO_StartLayer failed!\n");
		goto END_8_1080P_8;
	}
	/*设置并使能VO通道*/
	s32Ret = SAMPLE_COMM_VO_StartChn(VoLayer, enVoMode);
	if (HI_SUCCESS != s32Ret)
	{
		SAMPLE_PRT("Start SAMPLE_COMM_VO_StartChn failed!\n");
		goto END_8_1080P_9;
	}
	 /*建立VO和VI之间的bind关系*/
	for(i=0;i<u32WndNum;i++)
	{
		VoChn = i;
		VpssGrp = i;
		vichn = 4*i;
		
		s32Ret = SAMPLE_COMM_VO_BindVi(VoLayer,VoChn,vichn);
		if (HI_SUCCESS != s32Ret)
		{
			SAMPLE_PRT("Start VO failed!\n");
			goto END_8_1080P_9;
		}
	}

	/******************************************
	step 7: HD0 switch mode 
	******************************************/
	VoDev = SAMPLE_VO_DEV_DHD0;
	VoLayer = SAMPLE_VO_LAYER_VHD0;
	enVoMode = VO_MODE_9MUX;
	while(1)
	{
		enPreVoMode = enVoMode;
	
		printf("please choose preview mode, press 'q' to exit this sample.\n"); 
		printf("\t0) 1 preview\n");
		printf("\t1) 4 preview\n");
		printf("\t2) 8 preview\n");
		printf("\tq) quit\n");
 
		ch = getchar();
        if (10 == ch)
        {
            continue;
        }
		getchar();
		if ('0' == ch)
		{
			u32WndNum = 1;
			enVoMode = VO_MODE_1MUX;
		}
		else if ('1' == ch)
		{
			u32WndNum = 4;
			enVoMode = VO_MODE_4MUX;
		}
		/*Indeed only 8 chns show*/
		else if ('2' == ch)
		{
			u32WndNum = 9;
			enVoMode = VO_MODE_9MUX;
		}
		else if ('q' == ch)
		{
			break;
		}
		else
		{
			SAMPLE_PRT("preview mode invaild! please try again.\n");
			continue;
		}
		SAMPLE_PRT("vo(%d) switch to %d mode\n", VoDev, u32WndNum);

		s32Ret= HI_MPI_VO_SetAttrBegin(VoLayer);
		if (HI_SUCCESS != s32Ret)
		{
			SAMPLE_PRT("Start VO failed!\n");
			goto END_8_1080P_9;
		}
		
		s32Ret = SAMPLE_COMM_VO_StopChn(VoLayer, enPreVoMode); /*禁用指定的视频输出通道*/
		if (HI_SUCCESS != s32Ret)
		{
			SAMPLE_PRT("Start VO failed!\n");
			goto END_8_1080P_9;
		}

		s32Ret = SAMPLE_COMM_VO_StartChn(VoLayer, enVoMode);
		if (HI_SUCCESS != s32Ret)
		{
			SAMPLE_PRT("Start VO failed!\n");
			goto END_8_1080P_9;
		}
		s32Ret= HI_MPI_VO_SetAttrEnd(VoLayer); /*设置视频层上的通道的设置属性结束*/
		if (HI_SUCCESS != s32Ret)
		{
			SAMPLE_PRT("Start VO failed!\n");
			goto END_8_1080P_9;
		}
	}

	/******************************************
	 step 8: exit process
	******************************************/
END_8_1080P_9:
	VoDev = SAMPLE_VO_DEV_DSD0;
	VoLayer = SAMPLE_VO_LAYER_VSD0;
	u32WndNum = 8;
	enVoMode = VO_MODE_9MUX;
	SAMPLE_COMM_VO_StopChn(VoLayer, enVoMode);
	for(i=0;i<u32WndNum;i++)
	{
		VoChn = i;
		VpssGrp = i;
		SAMPLE_COMM_VO_UnBindVpss(VoLayer,VoChn,VpssGrp,VpssChn_VoSD0);
	}
	SAMPLE_COMM_VO_StopLayer(VoLayer);	
END_8_1080P_8:
	
	SAMPLE_COMM_VO_StopDev(VoDev);

END_8_1080P_7:
	#ifdef HDMI_SUPPORT
	if (stVoPubAttr_hd1.enIntfType & VO_INTF_HDMI)
	{
		SAMPLE_COMM_VO_HdmiStop();
	}
	#endif
	VoDev = SAMPLE_VO_DEV_DHD1;
	VoLayer = SAMPLE_VO_LAYER_VHD1;
	u32WndNum = 8;
	enVoMode = VO_MODE_9MUX;	
	SAMPLE_COMM_VO_StopChn(VoLayer, enVoMode);
	for(i=0;i<u32WndNum;i++)
	{
		VoChn = i;
		VpssGrp = i;
		SAMPLE_COMM_VO_UnBindVpss(VoLayer,VoChn,VpssGrp,VpssChn_VoHD1);
	}
	SAMPLE_COMM_VO_StopLayer(VoLayer);

END_8_1080P_6:
	SAMPLE_COMM_VO_StopDev(VoDev);

END_8_1080P_5:

	#ifdef HDMI_SUPPORT
	if (stVoPubAttr_hd0.enIntfType & VO_INTF_HDMI)
	{
		SAMPLE_COMM_VO_HdmiStop();
	}
	#endif

    VoDev = SAMPLE_VO_DEV_DHD0;
	VoLayer = SAMPLE_VO_LAYER_VHD0;
	u32WndNum = 8;
	enVoMode = VO_MODE_9MUX;	
	SAMPLE_COMM_VO_StopChn(VoLayer, enVoMode);
	for(i=0;i<u32WndNum;i++)
	{
		VoChn = i;
		VpssGrp = i;
		SAMPLE_COMM_VO_UnBindVpss(VoLayer,VoChn,VpssGrp,VpssChn_VoHD0);
	}
	SAMPLE_COMM_VO_StopLayer(VoLayer);
END_8_1080P_4:
	SAMPLE_COMM_VO_StopDev(VoDev);
END_8_1080P_3:	//vi unbind vpss
	SAMPLE_COMM_VI_UnBindVpss(enViMode);
END_8_1080P_2:	//vpss stop
	SAMPLE_COMM_VPSS_Stop(s32VpssGrpCnt, VPSS_MAX_CHN_NUM);
END_8_1080P_1:	//vi stop
	SAMPLE_COMM_VI_Stop(enViMode);
END_8_1080P_0:	//system exit
	SAMPLE_COMM_SYS_Exit();
	
	return s32Ret;
}

/******************************************************************************
* function : VI(D1) -> VPSS grp 0 -> VO HD0(1080p)
*            VI(D1) -> VPSS grp 1 -> VO PIP
******************************************************************************/
HI_S32 SAMPLE_VIO_HD_ZoomIn()
{
    SAMPLE_VI_MODE_E enViMode = SAMPLE_VI_MODE_8_720P; //SAMPLE_VI_MODE_8_1080P;
	VIDEO_NORM_E enNorm = VIDEO_ENCODING_MODE_PAL;

    HI_U32 u32ViChnCnt = 8;
    HI_S32 s32VpssGrpCnt = 8;
    VPSS_GRP VpssGrp = 0;
    VPSS_GRP VpssGrp_Clip = 1;
	VPSS_CHN VpssChn_VoHD0 = VPSS_CHN1;
	VPSS_CHN VpssChn_VoPIP = VPSS_CHN2;
    VO_DEV VoDev = SAMPLE_VO_DEV_DHD0;
	VO_LAYER VoLayer = SAMPLE_VO_LAYER_VHD0;
	VO_LAYER VoLayerPip = SAMPLE_VO_LAYER_VPIP;
    VO_CHN VoChn = 0;
    
    VB_CONF_S stVbConf;
    VPSS_GRP_ATTR_S stGrpAttr;
    VO_PUB_ATTR_S stVoPubAttr; 
    SAMPLE_VO_MODE_E enVoMode;
    VPSS_CROP_INFO_S stVpssCropInfo;
	VO_VIDEO_LAYER_ATTR_S stLayerAttr;
    SIZE_S stSize;
    
    HI_S32 i;
    HI_S32 s32Ret = HI_SUCCESS;
    HI_U32 u32BlkSize;
    HI_CHAR ch;
    HI_U32 u32WndNum;

	printf("[%s]:Begin line:%d\n", __func__, __LINE__);
    /******************************************
     step  1: init variable 
    ******************************************/    
    memset(&stVbConf,0,sizeof(VB_CONF_S));
    u32BlkSize = SAMPLE_COMM_SYS_CalcPicVbBlkSize(enNorm,\
                PIC_HD1080, SAMPLE_PIXEL_FORMAT, SAMPLE_SYS_ALIGN_WIDTH,COMPRESS_MODE_SEG);
    stVbConf.u32MaxPoolCnt = 128;

    /* video buffer*/
    //todo: vb=15
    stVbConf.astCommPool[0].u32BlkSize = u32BlkSize;
    stVbConf.astCommPool[0].u32BlkCnt = u32ViChnCnt * 8;

    /******************************************
     step 2: mpp system init. 
    ******************************************/
    s32Ret = SAMPLE_COMM_SYS_Init(&stVbConf);
    if (HI_SUCCESS != s32Ret)
    {
        SAMPLE_PRT("system init failed with %d!\n", s32Ret);
        goto END_HDZOOMIN_0;
    }

    /******************************************
     step 3: start vi dev & chn
    ******************************************/
    s32Ret = SAMPLE_COMM_VI_Start(enViMode, enNorm);
    if (HI_SUCCESS != s32Ret)
    {
        SAMPLE_PRT("start vi failed!\n");
        goto END_HDZOOMIN_0;
    }

    /******************************************
     step 4: start vpss and vi bind vpss
    ******************************************/
    s32Ret = SAMPLE_COMM_SYS_GetPicSize(enNorm, PIC_HD1080, &stSize);
    if (HI_SUCCESS != s32Ret)
    {
        SAMPLE_PRT("SAMPLE_COMM_SYS_GetPicSize failed!\n");
        goto END_HDZOOMIN_0;
    }

	memset(&stGrpAttr,0,sizeof(VPSS_GRP_ATTR_S));
	stGrpAttr.u32MaxW = stSize.u32Width;
	stGrpAttr.u32MaxH = stSize.u32Height;
	stGrpAttr.bNrEn = HI_TRUE;
    stGrpAttr.enDieMode = VPSS_DIE_MODE_NODIE;
	stGrpAttr.enPixFmt = SAMPLE_PIXEL_FORMAT;
    s32Ret = SAMPLE_COMM_VPSS_Start(s32VpssGrpCnt, &stSize, VPSS_MAX_CHN_NUM,NULL);
    if (HI_SUCCESS != s32Ret)
    {
        SAMPLE_PRT("Start Vpss failed!\n");
        goto END_HDZOOMIN_1;
    }

    s32Ret = SAMPLE_COMM_VI_BindVpss(enViMode);
    if (HI_SUCCESS != s32Ret)
    {
        SAMPLE_PRT("Vi bind Vpss failed!\n");
        goto END_HDZOOMIN_2;
    }

    /******************************************
     step 5: start VO to preview
    ******************************************/
	printf("start vo HD0.\n");
	VoDev = SAMPLE_VO_DEV_DHD0;
	VoLayer = SAMPLE_VO_LAYER_VHD0;
	u32WndNum = 1;
	enVoMode = VO_MODE_1MUX;
	
	stVoPubAttr.enIntfSync = VO_OUTPUT_1080P30;
	stVoPubAttr.enIntfType = VO_INTF_HDMI|VO_INTF_VGA;
	stVoPubAttr.u32BgColor = 0x000000ff;
	s32Ret = SAMPLE_COMM_VO_StartDev(VoDev, &stVoPubAttr);
	if (HI_SUCCESS != s32Ret)
	{
		SAMPLE_PRT("Start SAMPLE_COMM_VO_StartDev failed!\n");
		goto END_HDZOOMIN_3;
	}

	memset(&(stLayerAttr), 0 , sizeof(VO_VIDEO_LAYER_ATTR_S));
	s32Ret = SAMPLE_COMM_VO_GetWH(stVoPubAttr.enIntfSync, \
		&stLayerAttr.stImageSize.u32Width, \
		&stLayerAttr.stImageSize.u32Height, \
		&stLayerAttr.u32DispFrmRt);
	if (HI_SUCCESS != s32Ret)
	{
		SAMPLE_PRT("Start SAMPLE_COMM_VO_GetWH failed!\n");
		goto END_HDZOOMIN_3;
	}
	stLayerAttr.enPixFormat = SAMPLE_PIXEL_FORMAT;
	stLayerAttr.stDispRect.s32X 	  = 0;
	stLayerAttr.stDispRect.s32Y 	  = 0;
	stLayerAttr.stDispRect.u32Width   = stLayerAttr.stImageSize.u32Width;
	stLayerAttr.stDispRect.u32Height  = stLayerAttr.stImageSize.u32Height;
	s32Ret = SAMPLE_COMM_VO_StartLayer(VoLayer, &stLayerAttr);
	if (HI_SUCCESS != s32Ret)
	{
		SAMPLE_PRT("Start SAMPLE_COMM_VO_StartLayer failed!\n");
		goto END_HDZOOMIN_3;
	}

	s32Ret = SAMPLE_COMM_VO_StartChn(VoLayer, enVoMode);
	if (HI_SUCCESS != s32Ret)
	{
		SAMPLE_PRT("Start SAMPLE_COMM_VO_StartChn failed!\n");
		goto END_HDZOOMIN_4;
	}

#ifdef HDMI_SUPPORT
	/* if it's displayed on HDMI, we should start HDMI */
	if (stVoPubAttr.enIntfType & VO_INTF_HDMI)
	{
		if (HI_SUCCESS != SAMPLE_COMM_VO_HdmiStart(stVoPubAttr.enIntfSync))
		{
			SAMPLE_PRT("Start SAMPLE_COMM_VO_HdmiStart failed!\n");
			goto END_HDZOOMIN_5;
		}
	}
#endif

	VoChn = 0;
	VpssGrp = 0;
	s32Ret = SAMPLE_COMM_VO_BindVpss(VoDev,VoChn,VpssGrp,VpssChn_VoHD0);
	if (HI_SUCCESS != s32Ret)
	{
		SAMPLE_PRT("Start VO failed!\n");
		goto END_HDZOOMIN_5;
	}

    /******************************************
     step 6: Clip process
    ******************************************/
    printf("press any key to show hd zoom.\n");
    getchar();
    /*** enable vo pip layer ***/
    stLayerAttr.bClusterMode = HI_TRUE;
    stLayerAttr.bDoubleFrame = HI_FALSE;
    stLayerAttr.enPixFormat = SAMPLE_PIXEL_FORMAT;
    //PIPĬ?ϰ????豸0
    HI_MPI_VO_UnBindVideoLayer(VoLayerPip, 0);
	s32Ret = HI_MPI_VO_BindVideoLayer(VoLayerPip, VoDev);
	if (HI_SUCCESS != s32Ret)
    {
        SAMPLE_PRT("HI_MPI_VO_BindVideoLayer failed with %#x!\n", s32Ret);
        goto END_HDZOOMIN_5;
    }

	memset(&stLayerAttr, 0 , sizeof(VO_VIDEO_LAYER_ATTR_S));
    s32Ret = SAMPLE_COMM_VO_GetWH(VO_OUTPUT_PAL, \
        &stLayerAttr.stDispRect.u32Width, \
        &stLayerAttr.stDispRect.u32Height, \
        &stLayerAttr.u32DispFrmRt);
    if (s32Ret != HI_SUCCESS)
    {
        SAMPLE_PRT("failed with %#x!\n", s32Ret);
        goto  END_HDZOOMIN_6;
    }
    stLayerAttr.stImageSize.u32Width = stLayerAttr.stDispRect.u32Width;
    stLayerAttr.stImageSize.u32Height = stLayerAttr.stDispRect.u32Height;
	stLayerAttr.enPixFormat = SAMPLE_PIXEL_FORMAT;
    s32Ret = SAMPLE_COMM_VO_StartLayer(VoLayerPip, &stLayerAttr);
    if (HI_SUCCESS != s32Ret)
    {
       SAMPLE_PRT("SAMPLE_COMM_VO_StartLayer failed!\n");
       goto END_HDZOOMIN_6;
    }

	enVoMode = VO_MODE_1MUX;
    s32Ret = SAMPLE_COMM_VO_StartChn(VoLayerPip,enVoMode);    
    if (s32Ret != HI_SUCCESS)
    {
        SAMPLE_PRT("failed with %#x!\n", s32Ret);
        goto  END_HDZOOMIN_7;
    }

	s32Ret = SAMPLE_COMM_VO_BindVpss(VoLayerPip, VoChn, VpssGrp_Clip, VpssChn_VoPIP);//VpssGrp_Clip
    if (HI_SUCCESS != s32Ret)
    {
        SAMPLE_PRT("SAMPLE_COMM_VO_BindVpss failed!\n");
        goto END_HDZOOMIN_8;
    }

	/*** enable vpss group clip ***/
    stVpssCropInfo.bEnable = HI_TRUE;
    stVpssCropInfo.enCropCoordinate = VPSS_CROP_ABS_COOR;
    stVpssCropInfo.stCropRect.s32X = 0;
    stVpssCropInfo.stCropRect.s32Y = 0;
    stVpssCropInfo.stCropRect.u32Height = 400;
    stVpssCropInfo.stCropRect.u32Width = 400;
    s32Ret = HI_MPI_VPSS_SetGrpCrop(VpssGrp_Clip, &stVpssCropInfo);
    if (HI_SUCCESS != s32Ret)
    {
        SAMPLE_PRT("HI_MPI_VPSS_SetGrpCrop failed with %#x!\n", s32Ret);
        goto END_HDZOOMIN_8;
    }
	
    printf("\npress 'q' to stop sample ... ... \n");
    while('q' != (ch = getchar()) )  {}
    goto END_HDZOOMIN_9;
    /******************************************
     step 7: exit process
    ******************************************/
	
END_HDZOOMIN_9:
	SAMPLE_COMM_VO_UnBindVpss(SAMPLE_VO_LAYER_VHD0, VoChn, VpssGrp_Clip, VpssChn_VoPIP);
END_HDZOOMIN_8:
	enVoMode = VO_MODE_1MUX;
	SAMPLE_COMM_VO_StopChn(VoLayerPip,enVoMode);
END_HDZOOMIN_7:
	SAMPLE_COMM_VO_StopLayer(VoLayerPip);	
END_HDZOOMIN_6:
	HI_MPI_VO_UnBindVideoLayer(SAMPLE_VO_DEV_DHD0,SAMPLE_VO_DEV_DHD0);
END_HDZOOMIN_5:
	VoDev = SAMPLE_VO_DEV_DHD0;
	VoLayer = SAMPLE_VO_LAYER_VHD0;
    u32WndNum = 1;
    enVoMode = VO_MODE_1MUX;
	for(i=0;i<u32WndNum;i++)
    {
        VoChn = i;
        VpssGrp = i;
        SAMPLE_COMM_VO_UnBindVpss(VoDev,VoChn,VpssGrp,VpssChn_VoHD0);
    }
    SAMPLE_COMM_VO_StopChn(VoDev, enVoMode);
END_HDZOOMIN_4:
	SAMPLE_COMM_VO_StopLayer(SAMPLE_VO_LAYER_VHD0);
	#ifdef HDMI_SUPPORT
    if (stVoPubAttr.enIntfType & VO_INTF_HDMI)
    {
        SAMPLE_COMM_VO_HdmiStop();
    }
	#endif
	SAMPLE_COMM_VO_StopDev(VoDev);
END_HDZOOMIN_3:    
    SAMPLE_COMM_VI_UnBindVpss(enViMode);
END_HDZOOMIN_2:
    SAMPLE_COMM_VPSS_Stop(s32VpssGrpCnt, VPSS_MAX_CHN_NUM);
END_HDZOOMIN_1:
    SAMPLE_COMM_VI_Stop(enViMode);
END_HDZOOMIN_0:
    SAMPLE_COMM_SYS_Exit();
    
    return s32Ret;
}

/******************************************************************************
* function    : main()
* Description : video preview sample
* Description:获取一个路视频，并将采集到的视频输出到显示器
******************************************************************************/
int main(int argc, char *argv[])
{
#if 1
	demoFunc();
	return 0;
#endif
#if 0
    HI_S32 s32Ret = HI_FAILURE;

    if ( (argc < 2) || (1 != strlen(argv[1])))
    {
        SAMPLE_VIO_Usage(argv[0]);
        return HI_FAILURE;
    }
    signal(SIGINT, SAMPLE_VIO_HandleSig);
    signal(SIGTERM, SAMPLE_VIO_HandleSig);

	switch(*argv[1])
	{
		case '0':/* VI:8*1080P;VPSS VO:HD0(HDMI|VGA); VPSS VO:SD0(CVBS)*/
			s32Ret = SAMPLE_VIO_8_1080P();
			break;	
		case '1':/* VI:1*1080 HD PIP ZoomIn*/
			s32Ret = SAMPLE_VIO_HD_ZoomIn();
			break;	
        default:
            printf("input invaild! please try again.\n");
            SAMPLE_VIO_Usage(argv[0]);
            return HI_FAILURE;
	}

    if (HI_SUCCESS == s32Ret)
        printf("program exit normally!\n");
    else
        printf("program exit abnormally!\n");
    exit(s32Ret);
#endif
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

