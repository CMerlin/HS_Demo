#!/bin/sh
#将所有的例子程序拷贝挂载文件
echo "[Begin]:intall all bin file *****************";
#1:测试HDMI 输出
#cp ./vdec/sample_vdec /
#2:测试HDMI输入A
#./adv7842.hdmi.a
#./adv7842_sample_vio 0
#3:测试HDMI输入B
#./adv7842.hdmi.b
#./adv7842_sample_vio 0
#4：测试VGA输入
#./adv7842.vga
#./adv7842_sample_vio 0
#5：测试SDI输入
#./tw6874
#./i2c_write_reg16 0xd0 0x44 0x81
#./tw6874_sample_vio_1080p 0
#6：
echo "[End]:intall all bin file *******************";
